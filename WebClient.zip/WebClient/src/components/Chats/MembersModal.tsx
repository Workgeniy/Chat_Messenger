import React from "react";
import type { Participant } from "../../lib/api";

type Props = {
    open: boolean;
    onClose: () => void;
    members: Participant[];
    myId: number;
    onDM: (userId: number) => void;
};

export default function MembersModal({ open, onClose, members, myId, onDM }: Props) {
    if (!open) return null;
    return (
        <div style={{
            position: "fixed", inset: 0, background: "rgba(0,0,0,.35)",
            display: "grid", placeItems: "center", zIndex: 1000
        }}>
            <div style={{ background: "#fff", borderRadius: 12, padding: 16, width: 420, maxHeight: "70vh", overflow: "auto" }}>
                <div style={{ display: "flex", alignItems: "center", marginBottom: 8 }}>
                    <h3 style={{ margin: 0 }}>Участники</h3>
                    <button style={{ marginLeft: "auto" }} onClick={onClose}>✕</button>
                </div>

                <ul style={{ listStyle: "none", padding: 0, margin: 0 }}>
                    {members.map(m => (
                        <li key={m.id} style={{ display: "flex", alignItems: "center", gap: 10, padding: "8px 0", borderBottom: "1px solid #eee" }}>
                            <img src={m.avatarUrl || "/avatar.svg"} alt="" style={{ width: 36, height: 36, borderRadius: "50%", objectFit: "cover" }} />
                            <div style={{ display: "flex", flexDirection: "column" }}>
                                <div style={{ fontWeight: 600 }}>{m.name}</div>
                                <div style={{ fontSize: 12, color: "#777" }}>
                                    {m.lastSeenMessageId ? `Прочитано до #${m.lastSeenMessageId}` : "—"}
                                </div>
                            </div>
                            {m.id === myId && <span style={{ marginLeft: "auto", fontSize: 12, color: "#777" }}>это вы</span>}
                            {"isAdmin" in m && (m as any).isAdmin && (
                                <span style={{ marginLeft: "auto", fontSize: 12, padding: "2px 6px", border: "1px solid #ddd", borderRadius: 6 }}>
                  Админ
                </span>
                            )}
                            {m.id !== myId && (
                                <button style={{ marginLeft: "auto" }} onClick={() => onDM(m.id)}>
                                    Написать
                                </button>
                            )}
                        </li>
                    ))}
                </ul>
            </div>
        </div>
    );
}